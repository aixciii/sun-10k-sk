import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter'
})

export const metadata: Metadata = {
  title: 'Deye SUN-10K Hybridný Menič | Oficiálny Importér Slovensko | SUN-10K.sk',
  description: '3-fázový hybridný menič Deye 10 kW s 10-ročnou zárukou. On-grid aj off-grid. Skladom Bratislava, doručenie 1–2 dni. Oficiálny importér SK Partner s.r.o.',
  keywords: 'Deye, hybridný menič, 10kW, fotovoltaika, solárny menič, off-grid, on-grid, LiFePO4 batéria, Slovensko',
  openGraph: {
    title: 'Deye SUN-10K Hybridný Menič | Oficiálny Importér Slovensko',
    description: '3-fázový hybridný menič Deye 10 kW s 10-ročnou zárukou. Skladom Bratislava.',
    type: 'website',
    locale: 'sk_SK',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="sk" className="bg-background">
      <body className={`${inter.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
